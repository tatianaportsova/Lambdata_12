# Lambdata_12

Using the package from PIPY instructions:

```py
from my_lambdata.my_mod import enlarge

enlarge(5) #> 500
```






<hr>

Contributing instructions.

## Installation

```sh
cd path/to/Lambdata_12
```

Install package dependencies:

``sh
pipenv install
```

## Usage

An example script, not what people will use when installour package, just an example:

```sh
python my_lambdata/my_script.py
```